import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { DashboardContainerComponent } from './components/dashboard-container/dashboard-container.component';
import { ContentAreaComponent } from './components/content-area/content-area.component';
import { HomeComponent } from './components/home/home.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ProfileComponent } from './components/profile/profile.component';
import { WishlistComponent } from './components/wishlist/wishlist.component';
import { OverviewComponent } from './components/overview/overview.component';
import { DocumentationComponent } from './components/documentation/documentation.component';
import { RatingReviewComponent } from './components/rating-review/rating-review.component';
import { PricingComponent } from './components/pricing/pricing.component';
import { HelpSupportComponent } from './components/help-support/help-support.component';
import { SummaryBoxComponent } from './components/summary-box/summary-box.component';
import { SearchBoxComponent } from './components/search-box/search-box.component';
import { HomeTabsComponent } from './components/home-tabs/home-tabs.component';
import { PricingCardComponent } from './components/pricing-card/pricing-card.component';

@NgModule({
  declarations: [
    SidebarComponent,
    DashboardContainerComponent,
    ContentAreaComponent,
    HomeComponent,
    DashboardComponent,
    ProfileComponent,
    WishlistComponent,
    OverviewComponent,
    DocumentationComponent,
    RatingReviewComponent,
    PricingComponent,
    HelpSupportComponent,
    SummaryBoxComponent,
    SearchBoxComponent,
    HomeTabsComponent,
    PricingCardComponent,
  ],
  imports: [CommonModule, DashboardRoutingModule],
})
export class DashboardModule {}
