import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-summary-box',
  templateUrl: './summary-box.component.html',
  styleUrls: ['./summary-box.component.css']
})
export class SummaryBoxComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
