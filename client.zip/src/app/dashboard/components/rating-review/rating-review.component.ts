import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rating-review',
  templateUrl: './rating-review.component.html',
  styleUrls: ['./rating-review.component.css']
})
export class RatingReviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
