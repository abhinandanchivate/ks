import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home-tabs',
  templateUrl: './home-tabs.component.html',
  styleUrls: ['./home-tabs.component.css'],
})
export class HomeTabsComponent implements OnInit {
  constructor(private router: Router) {}

  ngOnInit(): void {}

  changeTab(url) {
    console.log(url);
    this.router.navigateByUrl(url);
  }
}
