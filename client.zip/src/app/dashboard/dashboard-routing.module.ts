import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardContainerComponent } from './components/dashboard-container/dashboard-container.component';
import { HomeComponent } from './components/home/home.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ProfileComponent } from './components/profile/profile.component';
import { WishlistComponent } from './components/wishlist/wishlist.component';
import { PricingComponent } from './components/pricing/pricing.component';
import { DocumentationComponent } from './components/documentation/documentation.component';
import { RatingReviewComponent } from './components/rating-review/rating-review.component';
import { HelpSupportComponent } from './components/help-support/help-support.component';
import { OverviewComponent } from './components/overview/overview.component';

const routes: Routes = [
  {
    path: '',
    component: DashboardContainerComponent,
    children: [
      {
        path: '',
        component: DashboardComponent,
      },

      {
        path: 'home',
        component: HomeComponent,
        children: [
          {
            path: '',
            redirectTo: 'overview',
          },
          {
            path: 'overview',
            component: OverviewComponent,
          },
          {
            path: 'pricing',
            component: PricingComponent,
          },
          {
            path: 'rating-review',
            component: RatingReviewComponent,
          },
          {
            path: 'documentation',
            component: DocumentationComponent,
          },
          {
            path: 'help',
            component: HelpSupportComponent,
          },
        ],
      },

      {
        path: 'profile',
        component: ProfileComponent,
      },

      {
        path: 'wishlist',
        component: WishlistComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DashboardRoutingModule {}
